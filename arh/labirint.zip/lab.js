(function (){

	let divLab = document.querySelector('.lab');
	
	let lab = [
		'111111111111111111111',
		'100010000010001000001',
		'111010111010111011101',
		'100010101000000000101',
		'101110101010111110111',
		'100000100010100000101',
		'101111111110101110101',
		'101000100000100010001',
		'111011101110111111111',
		'100010000010000000001',
		'101111101010111111101',
		'100000001010001000001',
		'111111111111111111111'
	];

	setPoint(getRandomCorridor(), 'g');
	setPoint(getRandomCorridor(), 'h');
	setPoint(getRandomCorridor(), 'm')

	drawLab();

	setButtonsEvent();

	function getRandomCorridor(){
		while (true) {
			let y = rnd(lab.length);
			let x = rnd(lab[y].length);
			if (lab[y][x] === '0') return { x, y };
		}
	}

	function setPoint(point, type) {
		let s = lab[point.y];
		lab[point.y] = s.substr(0, point.x) + type + s.substr(point.x + 1);
	}

	function rnd(n){
		return Math.floor(Math.random() * n);
	}

	function drawLab(){
		for (let y = 0; y < lab.length; y++) {
			let p = document.createElement('p');
			for (let x = 0; x < lab[y].length; x++) {
				let span = document.createElement('span');
				if (lab[y][x] === '1') span.className = 'wall';
				if (lab[y][x] === 'g') span.className = 'gold';
				if (lab[y][x] === 'h') span.className = 'hero';
				if (lab[y][x] === 'm') span.className = 'monstr';
				p.appendChild(span);
			}
			divLab.appendChild(p);
		}
	}
	
	function setButtonsEvent(){
		document.getElementById('btnUp').onclick = function (){ heroGoUp(); };
		document.getElementById('btnLf').onclick = function (){ heroGoLf(); };
		document.getElementById('btnDn').onclick = function (){ heroGoDn(); };
		document.getElementById('btnRt').onclick = function (){ heroGoRt(); };
		/* кнопки стрілки і WASD */
	}
	
	function heroGoUp(){ console.log('go Up'); }
	function heroGoLf(){ console.log('go Lf'); }
	function heroGoDn(){ console.log('go Dn'); }
	function heroGoRt(){ console.log('go Rt'); }

})();
